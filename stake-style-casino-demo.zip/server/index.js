
import express from "express";
import http from "http";
import { WebSocketServer } from "ws";
import next from "next";

const dev = true;
const app = next({ dev, dir: "./web" });
const handle = app.getRequestHandler();

await app.prepare();
const server = express();
const httpServer = http.createServer(server);
const wss = new WebSocketServer({ server: httpServer });

wss.on("connection", ws => {
  ws.send(JSON.stringify({ type: "WELCOME", msg: "Real-time engine online" }));
});

server.all("*", (req, res) => handle(req, res));

httpServer.listen(3000, () => console.log("Casino demo running on :3000"));

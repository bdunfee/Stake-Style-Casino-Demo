
import crypto from "crypto";
export function provableRoll(serverSeed, clientSeed, nonce) {
  const h = crypto.createHmac("sha256", serverSeed)
    .update(`${clientSeed}:${nonce}`).digest("hex");
  return (parseInt(h.slice(0, 8), 16) % 10000) / 100;
}

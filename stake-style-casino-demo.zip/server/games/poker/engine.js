
export function deal() {
  const suits = ["H","D","C","S"];
  const ranks = "23456789TJQKA".split("");
  const deck = suits.flatMap(s => ranks.map(r => r+s));
  for (let i=deck.length-1;i>0;i--) {
    const j = Math.floor(Math.random()*(i+1));
    [deck[i],deck[j]]=[deck[j],deck[i]];
  }
  return deck.slice(0,10);
}

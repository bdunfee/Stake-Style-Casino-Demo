
export function playDice(bet, roll) {
  return roll < bet.target ? bet.amount * bet.payout : 0;
}

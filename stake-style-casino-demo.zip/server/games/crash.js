
export function crashMultiplier(seed) {
  const n = parseInt(seed.slice(0, 8), 16) % 100;
  return Math.max(1.01, n / 10);
}

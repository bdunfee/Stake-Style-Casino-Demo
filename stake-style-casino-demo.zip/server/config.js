
export const CONFIG = {
  MODE: "DEMO",
  REAL_PAYMENTS_ENABLED: false,
  HOUSE_EDGE: { dice: 0.01, crash: 0.02, slots: 0.04 }
};


export default function Home() {
  return (
    <div style={{background:'#0b0f19',color:'#fff',minHeight:'100vh',padding:40}}>
      <h1>Stake‑Style Casino (DEMO)</h1>
      <p>Dice • Crash • Poker • VIP • Admin</p>
      <p>Demo mode only. No real money.</p>
    </div>
  );
}

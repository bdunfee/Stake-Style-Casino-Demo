
# Stake‑Style Casino DEMO (Replit)

## Run
Click Run on Replit. Demo mode only.

## Production Flip Checklist (POST‑LICENSE)
- [ ] Set CONFIG.MODE = REAL
- [ ] Enable KYC provider (Sumsub/Onfido)
- [ ] Enable real payment adapter
- [ ] Lock jurisdictions
- [ ] External security audit
- [ ] Regulator walkthrough

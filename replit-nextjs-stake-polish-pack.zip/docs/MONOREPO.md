
apps/ui -> Next.js frontend
apps/engine -> realtime + game logic
Shared via WebSockets / APIs

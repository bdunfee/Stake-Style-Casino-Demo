
const WebSocket = require('ws');
const wss = new WebSocket.Server({ port: 8081 });
setInterval(()=>{
  const msg = JSON.stringify({t:Date.now(),value:Math.random()*100});
  wss.clients.forEach(c=>c.readyState===1&&c.send(msg));
},1000);


export default function Walkthrough(){
  return (
    <div style={{padding:24}}>
      <h1>Regulator Walkthrough</h1>
      <ol>
        <li>Demo balances only</li>
        <li>Provably fair RNG</li>
        <li>Geo-blocking enabled</li>
        <li>Audit logs available</li>
      </ol>
    </div>
  );
}

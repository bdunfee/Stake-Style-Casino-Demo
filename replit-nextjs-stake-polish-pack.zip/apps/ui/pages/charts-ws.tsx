
import { useEffect, useState } from 'react';
import { LineChart, Line, XAxis, YAxis } from 'recharts';
export default function ChartsWS(){
  const [data,setData]=useState([]);
  useEffect(()=>{
    const ws=new WebSocket('wss://'+location.host+'/ws');
    ws.onmessage=e=>setData(d=>[...d.slice(-20),JSON.parse(e.data)]);
  },[]);
  return (
    <LineChart width={600} height={300} data={data}>
      <XAxis dataKey="t"/><YAxis/>
      <Line dataKey="value" stroke="#3bc48b"/>
    </LineChart>
  );
}

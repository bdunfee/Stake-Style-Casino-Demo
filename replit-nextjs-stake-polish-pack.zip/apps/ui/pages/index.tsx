
import Navbar from "../components/Navbar";
import "../styles/lobby.css";
export default function Lobby(){
  return (
    <>
      <Navbar/>
      <div className="lobby">
        {["Slots","Poker","Casino","Sports"].map(g=>(
          <div key={g} className="tile">{g}</div>
        ))}
      </div>
    </>
  );
}

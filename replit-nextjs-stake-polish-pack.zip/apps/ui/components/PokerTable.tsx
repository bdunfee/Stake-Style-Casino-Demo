
export default function PokerTable(){
  return (
    <div style={{padding:24,animation:"fade .3s"}}>
      <h2>Poker Table</h2>
      <p className="deal">Dealing cards...</p>
      <style jsx>{`
        @keyframes fade{from{opacity:0}to{opacity:1}}
        .deal{animation:pulse 1s infinite}
        @keyframes pulse{0%{opacity:.4}50%{opacity:1}100%{opacity:.4}}
      `}</style>
    </div>
  );
}

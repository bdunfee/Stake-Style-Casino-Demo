
import http from 'http';
import next from 'next';
import { WebSocketServer } from 'ws';

const dev = true;
const app = next({ dev });
const handle = app.getRequestHandler();

app.prepare().then(() => {
  const server = http.createServer((req, res) => handle(req, res));
  const wss = new WebSocketServer({ server, path: "/ws" });

  setInterval(() => {
    const payload = JSON.stringify({
      users: Math.floor(Math.random()*200),
      bets: Math.floor(Math.random()*500)
    });
    wss.clients.forEach(c => c.readyState === 1 && c.send(payload));
  }, 1000);

  server.listen(3000, "0.0.0.0", () =>
    console.log("Next.js + WS running")
  );
});

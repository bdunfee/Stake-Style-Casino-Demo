
import Navbar from "../components/Navbar";
export default function Poker(){
  return (
    <>
      <Navbar/>
      <main style={{padding:24}}>
        <h1>Poker Table (Demo)</h1>
        <p>Players + bots simulated</p>
      </main>
    </>
  );
}


import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
export default function Home(){
  return (
    <>
      <Navbar/>
      <main style={{padding:24}}>
        <h1>Stake Demo Lobby</h1>
      </main>
      <Footer/>
    </>
  );
}

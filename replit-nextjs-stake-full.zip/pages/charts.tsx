
import { useEffect, useState } from "react";
import Navbar from "../components/Navbar";
export default function Charts(){
  const [data,setData]=useState([]);
  useEffect(()=>{
    const ws=new WebSocket("ws://"+location.host+"/ws");
    ws.onmessage=e=>setData(d=>[...d.slice(-20),JSON.parse(e.data)]);
  },[]);
  return (
    <>
      <Navbar/>
      <pre>{JSON.stringify(data,null,2)}</pre>
    </>
  );
}

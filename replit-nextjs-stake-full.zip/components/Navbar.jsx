
import Link from "next/link";
export default function Navbar(){
  return (
    <nav style={{display:'flex',gap:16,padding:16,background:'#1a2c38'}}>
      <Link href="/">Lobby</Link>
      <Link href="/poker">Poker</Link>
      <Link href="/charts">Live Charts</Link>
    </nav>
  );
}


export default function Footer(){
  return (
    <footer style={{padding:16,opacity:.6,textAlign:'center'}}>
      Demo only • No real money
    </footer>
  );
}

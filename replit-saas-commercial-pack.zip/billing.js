
// Simple revenue share calculator
function calcRevShare(ggr, operatorShare=0.7){
  return {
    operator: ggr * operatorShare,
    platform: ggr * (1-operatorShare)
  };
}

module.exports = { calcRevShare };

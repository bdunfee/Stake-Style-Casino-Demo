
House Edge Configuration
- Per-tenant configurable
- Applied at game resolution
- Poker uses rake percentage
- Demo-safe, auditable constants

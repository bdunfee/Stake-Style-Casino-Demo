
const wallets = new Map(); // key: tenant:userId -> balance

function key(tenant, userId){ return `${tenant}:${userId}`; }

function getBalance(tenant, userId){
  return wallets.get(key(tenant,userId)) || 0;
}

function credit(tenant, userId, amount){
  const k = key(tenant,userId);
  wallets.set(k, getBalance(tenant,userId) + amount);
}

function debit(tenant, userId, amount){
  const bal = getBalance(tenant,userId);
  if (bal < amount) throw new Error("Insufficient funds");
  wallets.set(key(tenant,userId), bal - amount);
}

module.exports = { getBalance, credit, debit };

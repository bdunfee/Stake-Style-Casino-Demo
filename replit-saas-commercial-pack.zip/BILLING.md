
Operator Billing & Revenue Share
- GGR calculated per tenant
- Default split: 70% operator / 30% platform
- Monthly settlement
- Demo mode uses simulated GGR


export default function DemoBanner() {
  return (
    <div className="w-full text-center py-2 bg-yellow-900 text-yellow-200">
      Locked Read-Only Demo • No wagering • For diligence only
    </div>
  );
}


export const READ_ONLY = true;

export function assertReadOnly() {
  if (!READ_ONLY) return;
  if (typeof window !== 'undefined') {
    console.warn('Read-only demo mode enabled');
  }
}


'use client';
import { useEffect, useState } from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import pricing from '../config/tenantPricing.json';

function getPreset() {
  if (typeof window === 'undefined') return null;
  const p = new URLSearchParams(window.location.search).get('preset');
  return p && pricing.presets[p] ? pricing.presets[p] : null;
}

export default function Calculator() {
  const preset = getPreset();
  const [tenant, setTenant] = useState(preset?.tenant || 'default');
  const [ggr, setGgr] = useState(preset?.ggr || 500000);

  const cfg = pricing.tenants[tenant];
  const revShare = cfg.revShare;
  const monthly = ggr * revShare;

  const data = [
    { name: 'Month 1', value: monthly * 1 },
    { name: 'Month 6', value: monthly * 6 },
    { name: 'Month 12', value: monthly * 12 }
  ];

  return (
    <div className="p-10">
      <h1 className="text-3xl mb-4">Sale vs Lease vs Rev-Share</h1>
      <p className="opacity-70 mb-6">Read-only diligence demo</p>

      <label className="block mb-2">Tenant</label>
      <select value={tenant} onChange={e => setTenant(e.target.value)} className="mb-4 p-2 rounded bg-black border">
        {Object.keys(pricing.tenants).map(t => (
          <option key={t} value={t}>{t}</option>
        ))}
      </select>

      <label className="block mb-2">Estimated Monthly GGR</label>
      <input type="number" value={ggr} onChange={e => setGgr(+e.target.value)} className="mb-6 p-2 rounded bg-black border w-full"/>

      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={data}>
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Line type="monotone" dataKey="value" strokeWidth={3} />
        </LineChart>
      </ResponsiveContainer>

      <div className="mt-6 space-y-2">
        <p><strong>Rev-share rate:</strong> {(revShare*100).toFixed(1)}%</p>
        <p><strong>Annual rev-share:</strong> ${(monthly*12).toLocaleString()}</p>
        <p><strong>One-time sale anchor:</strong> ${cfg.sale.toLocaleString()}</p>
        <p><strong>Monthly lease:</strong> ${cfg.lease.toLocaleString()}</p>
      </div>
    </div>
  );
}

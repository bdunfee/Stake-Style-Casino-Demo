
export default ()=> <div className="nav">Stake Demo</div>;


import Navbar from "../components/Navbar";
export default ()=> <div><Navbar/><h2>Casino Lobby</h2></div>;


export default ()=> <h2>Poker Table</h2>;


export default ()=> <h2>VIP</h2>;

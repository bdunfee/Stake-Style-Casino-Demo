
export default ()=> <h2>Fraud Dashboard</h2>;

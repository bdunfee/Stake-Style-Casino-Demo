
import express from "express";
import http from "http";
import { WebSocketServer } from "ws";
import next from "next";
import { pokerWS } from "./ws/poker.js";
import { fraudScore } from "./fraud.js";

const app = next({ dev:true, dir:"./web" });
await app.prepare();
const handle = app.getRequestHandler();
const server = express();
server.use(express.json());
server.post("/admin/fraud",(req,res)=>res.json({score:fraudScore(req.body)}));

const httpServer=http.createServer(server);
const wss=new WebSocketServer({server:httpServer});
pokerWS(wss);

server.all("*",(req,res)=>handle(req,res));
httpServer.listen(3000);

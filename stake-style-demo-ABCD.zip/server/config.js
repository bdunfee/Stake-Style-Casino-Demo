
export const CONFIG = {
  MODE: "DEMO",
  HOUSE_EDGE: { poker: 0.03 }
};


export function fraudScore(user){
  return Math.min(1, (user.bets||0)/50 + (user.winrate||0));
}

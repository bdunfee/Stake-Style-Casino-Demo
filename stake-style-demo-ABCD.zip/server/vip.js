
export function vipForXp(xp){
  if(xp>20000) return "Platinum";
  if(xp>5000) return "Gold";
  if(xp>1000) return "Silver";
  return "Bronze";
}

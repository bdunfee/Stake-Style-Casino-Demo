
import { join, table } from "../games/poker/engine.js";
export function pokerWS(wss){
  wss.on("connection", ws=>{
    join("human");
    ws.send(JSON.stringify(table));
  });
}

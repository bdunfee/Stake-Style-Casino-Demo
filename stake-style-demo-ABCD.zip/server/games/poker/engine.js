
export const table={players:[],pot:0};
export function join(player){table.players.push(player);}


Stake-style DEMO (ABCD)

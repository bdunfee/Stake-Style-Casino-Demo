
'use client';
import Link from 'next/link';
export default function Strategic() {
  return (
    <div className="p-12 max-w-4xl mx-auto">
      <h1 className="text-4xl mb-4">Strategic Operator Opportunity</h1>
      <p className="opacity-80 mb-6">Private diligence view • Read-only demo</p>
      <Link href="/calculator" className="px-6 py-3 rounded-xl bg-emerald-600">View Economics</Link>
    </div>
  );
}

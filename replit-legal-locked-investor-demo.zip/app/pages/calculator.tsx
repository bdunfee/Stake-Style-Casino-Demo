
'use client';
import { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import meta from '../config/build.json';

export default function Calculator() {
  const [ggr, setGgr] = useState(1000000);
  const operatorMargin = 0.55;
  const revShare = 0.15;

  const operatorProfit = ggr * operatorMargin * (1 - revShare);
  const yourTake = ggr * operatorMargin * revShare;

  const waterfall = [
    { stage: 'GGR', value: ggr },
    { stage: 'After Costs', value: ggr * operatorMargin },
    { stage: 'Operator Profit', value: operatorProfit },
    { stage: 'Your Rev-Share', value: yourTake }
  ];

  return (
    <div className="p-10">
      <h1 className="text-3xl mb-2">Revenue Waterfall & Profit Split</h1>
      <p className="opacity-70 mb-4">Build {meta.version} • {meta.buildHash}</p>

      <input type="number" value={ggr} onChange={e=>setGgr(+e.target.value)} className="mb-6 p-2 rounded bg-black border w-full"/>

      <ResponsiveContainer width="100%" height={260}>
        <AreaChart data={waterfall}>
          <XAxis dataKey="stage" />
          <YAxis />
          <Tooltip />
          <Area dataKey="value" fillOpacity={0.6} />
        </AreaChart>
      </ResponsiveContainer>

      <div className="mt-6 grid grid-cols-2 gap-4">
        <div className="p-4 rounded-xl bg-zinc-900">
          <h3 className="text-lg mb-1">Operator Annual Profit</h3>
          <p className="text-2xl">${operatorProfit.toLocaleString()}</p>
        </div>
        <div className="p-4 rounded-xl bg-zinc-900">
          <h3 className="text-lg mb-1">Your Annual Take</h3>
          <p className="text-2xl">${yourTake.toLocaleString()}</p>
        </div>
      </div>
    </div>
  );
}

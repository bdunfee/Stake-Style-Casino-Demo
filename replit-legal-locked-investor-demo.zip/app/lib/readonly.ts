
export const READ_ONLY = true;
export function ensureReadOnly() {
  if (READ_ONLY && typeof window !== 'undefined') {
    console.info('Read-only legal demo build');
  }
}

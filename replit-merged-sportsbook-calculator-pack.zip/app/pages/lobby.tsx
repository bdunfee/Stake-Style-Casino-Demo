
import SportsbookTile from '../components/SportsbookTile';

export default function Lobby() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-8 p-10">
      {/* Existing tiles would be here */}
      <SportsbookTile />
    </div>
  );
}


'use client';
import { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

const bands = {
  small: { sale: 150000, lease: 5000 },
  mid: { sale: 350000, lease: 12000 },
  large: { sale: 800000, lease: 30000 }
};

export default function Calculator() {
  const [size, setSize] = useState('mid');
  const data = [
    { name: 'Sale', value: bands[size].sale },
    { name: 'Lease / yr', value: bands[size].lease * 12 }
  ];

  return (
    <div className="p-10">
      <h1 className="text-3xl mb-4">Sale vs Lease Calculator</h1>
      <select
        value={size}
        onChange={(e) => setSize(e.target.value)}
        className="mb-6 p-2 rounded bg-black border"
      >
        <option value="small">Small Operator</option>
        <option value="mid">Mid Operator</option>
        <option value="large">Large Operator</option>
      </select>

      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={data}>
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Line type="monotone" dataKey="value" strokeWidth={3} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

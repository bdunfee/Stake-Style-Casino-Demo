
'use client';
import { motion } from 'framer-motion';

export default function SportsbookTile() {
  return (
    <motion.div
      whileHover={{ scale: 1.03 }}
      className="rounded-2xl bg-gradient-to-br from-emerald-900 to-black p-6 shadow-xl"
    >
      <h3 className="text-2xl font-semibold mb-2">Sportsbook</h3>
      <p className="opacity-80 mb-4">Live demo markets • Pre-license mode</p>
      <button className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500">
        View Demo
      </button>
    </motion.div>
  );
}

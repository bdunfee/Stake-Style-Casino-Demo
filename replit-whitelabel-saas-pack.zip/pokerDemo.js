
const players = [
  { id: 1, name: "BubbaBot Easy", skill: 0.3 },
  { id: 2, name: "BubbaBot Medium", skill: 0.6 },
  { id: 3, name: "BubbaBot Hard", skill: 0.9 }
];

function simulateHand() {
  return players.map(p => ({
    player: p.name,
    decision: Math.random() < p.skill ? "RAISE" : "CALL"
  }));
}

module.exports = { simulateHand };

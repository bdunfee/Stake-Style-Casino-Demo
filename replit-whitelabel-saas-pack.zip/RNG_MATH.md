
# RNG Math Documentation (Demo)

## Overview
This demo uses SHA-256 hashing for provably fair outcomes.
Final outcomes are derived from hashed seeds and mapped to game results.

## Formula
hash = SHA256(serverSeed : clientSeed : nonce)

## Mapping
- Slots: hash modulo reel size
- Dice: (hash % 10000) / 100
- Poker: deterministic shuffle using hash stream

## House Edge
Configured per game via constants and documented per jurisdiction.

> Note: This documentation is for demonstration and pre-certification review only.

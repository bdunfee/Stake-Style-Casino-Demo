
import { useState } from "react";
import crypto from "crypto";

function sha256(input) {
  return crypto.createHash("sha256").update(input).digest("hex");
}

export default function ProvablyFairVisualizer() {
  const [serverSeed, setServerSeed] = useState("server-seed-example");
  const [clientSeed, setClientSeed] = useState("client-seed-example");
  const [nonce, setNonce] = useState(0);
  const [hash, setHash] = useState("");

  const compute = () => {
    const combined = `${serverSeed}:${clientSeed}:${nonce}`;
    setHash(sha256(combined));
  };

  return (
    <div className="p-6 bg-neutral-900 rounded-2xl text-white max-w-xl">
      <h2 className="text-lg font-semibold mb-4">Provably Fair Visualizer</h2>
      <input className="w-full mb-2 p-2 rounded bg-neutral-800" value={serverSeed} onChange={e=>setServerSeed(e.target.value)} placeholder="Server Seed" />
      <input className="w-full mb-2 p-2 rounded bg-neutral-800" value={clientSeed} onChange={e=>setClientSeed(e.target.value)} placeholder="Client Seed" />
      <input className="w-full mb-4 p-2 rounded bg-neutral-800" type="number" value={nonce} onChange={e=>setNonce(Number(e.target.value))} />
      <button onClick={compute} className="bg-green-500 text-black px-4 py-2 rounded">Compute</button>
      {hash && <pre className="mt-4 text-xs break-all">{hash}</pre>}
    </div>
  );
}

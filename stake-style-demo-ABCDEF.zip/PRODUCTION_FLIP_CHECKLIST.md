
# Production Flip Checklist (POST-LICENSE)

LEGAL
- Curaçao license approved
- Entity verified
- Terms & Responsible Gaming live

TECH
- MODE switched to REAL
- KYC provider enabled
- Payments enabled
- Jurisdiction blocks enforced
- External security audit complete

OPS
- Incident response trained
- AML reporting active
- Regulator credentials issued

FINAL
- Regulator sign-off
- Production DNS switch

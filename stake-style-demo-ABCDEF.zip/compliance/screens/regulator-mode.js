
// Enables regulator-only banners and read-only mode
export const regulatorMode = {
  banner: true,
  readonly: true,
  watermark: "REGULATOR DEMO MODE"
};

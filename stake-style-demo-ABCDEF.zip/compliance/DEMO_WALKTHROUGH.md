
# Regulator Demo Walkthrough (DEMO MODE)

## Credentials
- Username: regulator_demo
- Password: demo-only
- Mode: DEMO (no real money)

## Walkthrough Steps
1. Login as regulator_demo
2. View Casino Lobby (no deposits)
3. Open Poker Table (play-money)
4. View Provably Fair logic
5. Open VIP page (rakeback demo)
6. Open Admin Panel
7. Review Fraud Score
8. Export Audit Logs (CSV)
9. Verify Jurisdiction Blocking (demo)
10. Confirm DEMO watermark

## Notes
- All balances are simulated
- No withdrawals possible
- All actions logged

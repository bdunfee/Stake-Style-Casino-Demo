
# Stake-Style Casino DEMO (ABCDEF)

Includes:
A) Stake-style UI
B) Multiplayer Poker
C) VIP + Rakeback
D) Fraud Dashboard
E) Regulator Demo Walkthrough
F) Auto-deploy Pipeline (DEMO locked)

Safe. Runnable. License-ready.

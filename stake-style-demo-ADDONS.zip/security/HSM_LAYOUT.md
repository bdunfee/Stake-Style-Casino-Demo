
# Key Management & HSM Layout (Design)

- Wallet keys stored in external HSM (e.g., AWS CloudHSM)
- App servers never access raw private keys
- Signing via secure API
- Separate hot/warm/cold key tiers
- Demo mode uses mock signer


export function snapshot(){
  return {
    activeUsers: Math.floor(Math.random()*100),
    betsPerMin: Math.floor(Math.random()*500),
    fraudAlerts: Math.floor(Math.random()*5)
  };
}


export function decide(actionState, tier="MEDIUM"){
  const r = Math.random();
  if(tier==="EASY") return r>.6?"CALL":"FOLD";
  if(tier==="HARD") return r>.3?"RAISE":"CALL";
  return r>.5?"CALL":"FOLD";
}


import { motion } from "framer-motion";
export const FadeIn = ({children}) => (
  <motion.div initial={{opacity:0,y:6}} animate={{opacity:1,y:0}} transition={{duration:.2}}>
    {children}
  </motion.div>
);


import { useEffect, useState } from "react";
export default function Analytics(){
  const [m,setM]=useState({});
  useEffect(()=>{
    fetch("/analytics").then(r=>r.json()).then(setM);
  },[]);
  return <pre>{JSON.stringify(m,null,2)}</pre>;
}


import { useEffect, useState } from 'react';
export default function ChartsLive(){
  const [points,setPoints]=useState([]);
  useEffect(()=>{
    const ws=new WebSocket('wss://'+location.host+'/ws');
    ws.onmessage=e=>setPoints(p=>[...p.slice(-20),JSON.parse(e.data).value]);
  },[]);
  return (
    <div style={{padding:24}}>
      <h1>Live WS Chart</h1>
      <pre>{JSON.stringify(points,null,2)}</pre>
    </div>
  );
}

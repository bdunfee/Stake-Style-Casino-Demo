
import { useState } from 'react';
import Navbar from '../components/Navbar';
import '../styles/slots.css';

export default function SlotsAnimated(){
  const [spinning,setSpinning]=useState(false);
  return (
    <>
      <Navbar/>
      <main className="slots-wrap">
        <h1>Animated Slots</h1>
        <div className={spinning?"reels spin":"reels"}>
          <div className="reel">🍒🍋🔔💎</div>
          <div className="reel">🍋🔔💎🍒</div>
          <div className="reel">🔔💎🍒🍋</div>
        </div>
        <button onClick={()=>{setSpinning(true);setTimeout(()=>setSpinning(false),1500)}}>
          SPIN
        </button>
      </main>
    </>
  );
}


export default function JurisdictionMap(){
  return (
    <div style={{padding:24}}>
      <h1>Jurisdiction Map (Demo)</h1>
      <svg width="400" height="200">
        <rect x="10" y="10" width="100" height="80" fill="#3bc48b"/>
        <text x="20" y="50">EU</text>
        <rect x="150" y="10" width="100" height="80" fill="#555"/>
        <text x="160" y="50">US (Blocked)</text>
      </svg>
    </div>
  );
}

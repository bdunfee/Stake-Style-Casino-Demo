
import { withRole } from '../lib/guard';
function AdminPanel(){
  return (
    <div style={{padding:24}}>
      <h1>Admin Panel</h1>
      <ul>
        <li>Users</li>
        <li>Games</li>
        <li>Fraud Alerts</li>
        <li>Compliance</li>
      </ul>
    </div>
  );
}
export default withRole(AdminPanel,'admin');

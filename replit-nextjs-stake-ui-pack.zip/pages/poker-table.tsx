
import Navbar from '../components/Navbar';
export default function PokerTable(){
  return (
    <>
      <Navbar/>
      <main style={{padding:24}}>
        <h1>Poker Table</h1>
        <div style={{border:'2px solid #2e2e2e',borderRadius:16,padding:32}}>
          <p>Player • Bot • Bot • Bot</p>
          <p>Community Cards: 🂡 🂱 🃑</p>
          <button>CHECK</button>
          <button>BET</button>
          <button>FOLD</button>
        </div>
      </main>
    </>
  );
}

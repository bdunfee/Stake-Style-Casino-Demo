Current Stage Valuation (Pre-License)

Comparable pre-license casino SaaS demos trade between:
- $250k – $750k (asset sale)
- $1.5M – $3M (equity valuation with roadmap)

Value drivers:
- Stake-level UI
- Compliance-first demo
- Multi-tenant SaaS readiness
- Poker + slots + sportsbook UI

Excludes:
- License
- Payments
- Revenue

Conclusion:
Strong strategic asset for operators or roll-ups.

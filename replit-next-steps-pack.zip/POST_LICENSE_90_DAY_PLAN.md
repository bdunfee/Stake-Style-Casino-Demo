90-Day Post-License Launch Plan

Days 1–30:
- Enable payments
- Activate live KYC/AML
- PSP onboarding
- Regulator reporting

Days 31–60:
- Soft launch (geo-limited)
- Affiliate onboarding
- Fraud tuning

Days 61–90:
- Marketing scale
- VIP programs live
- Data-driven optimization

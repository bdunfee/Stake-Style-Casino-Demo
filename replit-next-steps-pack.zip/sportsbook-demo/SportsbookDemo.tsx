
import React from 'react';

export default function SportsbookDemo() {
  const games = [
    { match: 'Team A vs Team B', odds: '1.90 / 2.10' },
    { match: 'Team C vs Team D', odds: '1.70 / 2.30' },
  ];

  return (
    <div style={{ padding: 24 }}>
      <h1>Sportsbook Demo (Betting Disabled)</h1>
      <p>UI-only preview. No wagers accepted.</p>
      {games.map((g, i) => (
        <div key={i} style={{ marginTop: 12, padding: 12, border: '1px solid #333' }}>
          <strong>{g.match}</strong>
          <div>Odds: {g.odds}</div>
          <button disabled style={{ marginTop: 8 }}>Simulate Bet</button>
        </div>
      ))}
    </div>
  );
}

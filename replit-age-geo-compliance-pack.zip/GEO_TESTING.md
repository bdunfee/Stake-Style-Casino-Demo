
Replit Geo Testing:
1. Open Demo Tools drawer
2. Set Simulated Country (UK/EU/ROW)
3. Refresh page
4. UK shows age modal
5. Others show footer disclaimer

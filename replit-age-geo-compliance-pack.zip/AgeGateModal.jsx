
import { useState, useEffect } from "react";

export default function AgeGateModal({ country }) {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (country === "UK") setOpen(true);
  }, [country]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80">
      <div className="bg-neutral-900 p-8 rounded-2xl max-w-md text-white">
        <h1 className="text-xl font-semibold mb-4">This site is for adults only (18+)</h1>
        <p className="text-sm mb-6">
          By continuing, you confirm you are at least 18 years old. This site is operating in demo mode only.
        </p>
        <button
          onClick={() => setOpen(false)}
          className="w-full bg-green-500 hover:bg-green-600 text-black py-2 rounded-xl"
        >
          I am 18 or over – Enter
        </button>
      </div>
    </div>
  );
}


CI Auto-Deploy (GitHub → Replit)

1. Push repo to GitHub
2. In Replit → Import from GitHub
3. Enable 'Auto-redeploy on push'
4. Main branch = production

Optional:
- GitHub Actions build
- Replit pulls on push

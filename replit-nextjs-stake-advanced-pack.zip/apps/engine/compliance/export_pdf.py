
from reportlab.platypus import SimpleDocTemplate, Paragraph
from reportlab.lib.styles import getSampleStyleSheet

doc = SimpleDocTemplate("compliance_report.pdf")
styles = getSampleStyleSheet()
content = [
  Paragraph("Demo Compliance Report", styles['Title']),
  Paragraph("All balances simulated", styles['Normal']),
  Paragraph("Provably fair enabled", styles['Normal']),
  Paragraph("Geo-blocking active", styles['Normal'])
]
doc.build(content)
print("Generated compliance_report.pdf")


import { useState } from 'react';
const regions = [
  {id:'EU',blocked:false},
  {id:'US',blocked:true},
  {id:'ASIA',blocked:false}
];
export default function JurisdictionInteractive(){
  const [map,setMap]=useState(regions);
  return (
    <div style={{padding:24}}>
      <h1>Jurisdiction Control</h1>
      {map.map(r=>(
        <div key={r.id}
          onClick={()=>setMap(m=>m.map(x=>x.id===r.id?{...x,blocked:!x.blocked}:x))}
          style={{cursor:'pointer',margin:8,padding:12,
            background:r.blocked?'#552':'#253'}}>
          {r.id} — {r.blocked?'BLOCKED':'ALLOWED'}
        </div>
      ))}
    </div>
  );
}

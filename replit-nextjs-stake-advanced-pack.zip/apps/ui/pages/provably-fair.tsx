
import { useState } from 'react';
import crypto from 'crypto';
export default function ProvablyFair(){
  const [seed,setSeed]=useState('demo-seed');
  const hash = crypto.createHash('sha256').update(seed).digest('hex');
  return (
    <div style={{padding:24}}>
      <h1>Provably Fair Visualizer</h1>
      <input value={seed} onChange={e=>setSeed(e.target.value)}/>
      <p>SHA256:</p>
      <pre>{hash}</pre>
    </div>
  );
}

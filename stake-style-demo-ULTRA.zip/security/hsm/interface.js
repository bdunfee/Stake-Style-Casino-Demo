
export class HSMProvider {
  async sign(payload){ throw new Error("Implement in production only"); }
  async verify(sig){ throw new Error("Implement in production only"); }
}

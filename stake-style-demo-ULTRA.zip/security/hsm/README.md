
# Real HSM Integration (Post-License)

This folder defines interfaces ONLY.
No keys. No secrets. No network calls.

Supported vendors:
- AWS CloudHSM
- GCP Cloud KMS
- Fireblocks

Production steps:
1. Provision HSM
2. Map signing API
3. Rotate keys quarterly
4. Enable audit logging

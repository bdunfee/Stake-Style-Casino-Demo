
import { WebSocketServer } from "ws";
export function startLiveStream(server){
  const wss = new WebSocketServer({ server, path: "/ws/live" });
  setInterval(()=>{
    const msg = JSON.stringify({ t: Date.now(), users: Math.random()*300 });
    wss.clients.forEach(c=>c.readyState===1 && c.send(msg));
  }, 1000);
}

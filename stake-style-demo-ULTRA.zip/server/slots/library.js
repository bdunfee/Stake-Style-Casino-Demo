
export const SlotMath = {
  paytable: { A:10, B:5, C:3, D:2 },
  reels: [
    ["A","B","C","D"],
    ["A","B","C","D"],
    ["A","B","C","D"],
    ["A","B","C","D"],
    ["A","B","C","D"]
  ],
  theoreticalRTP: 0.96 // informational only
};

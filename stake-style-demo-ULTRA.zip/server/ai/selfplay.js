
export function selfPlay(agentA, agentB, rounds=100){
  for(let i=0;i<rounds;i++){
    agentA.skill += Math.random()*0.01;
    agentB.skill += Math.random()*0.01;
  }
  return { agentA, agentB };
}

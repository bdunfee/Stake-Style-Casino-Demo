
import themes from './themes.json';
export function applyTheme(name){
  const t=themes[name];
  document.body.style.background=t.bg;
  document.documentElement.style.setProperty('--accent', t.accent);
}

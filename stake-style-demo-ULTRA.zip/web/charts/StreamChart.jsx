
import { useEffect, useState } from "react";
export default function StreamChart(){
  const [data,setData]=useState([]);
  useEffect(()=>{
    const ws=new WebSocket("ws://localhost:3000/ws/live");
    ws.onmessage=e=>setData(d=>[...d.slice(-30), JSON.parse(e.data)]);
  },[]);
  return <pre>{JSON.stringify(data,null,2)}</pre>;
}

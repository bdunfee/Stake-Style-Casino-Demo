
export class PaymentAdapter {
  constructor(provider="MOCK"){ this.provider=provider }
  deposit(amount){
    if(this.provider==="MOCK") return {status:"ok", tx:"demo"};
  }
}

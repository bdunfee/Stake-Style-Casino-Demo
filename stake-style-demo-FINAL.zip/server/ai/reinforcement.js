
export function train(agent, reward){
  agent.score += reward;
  return agent;
}

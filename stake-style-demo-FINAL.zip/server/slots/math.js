
export const SLOT_DEMO = {
  reels: 5,
  symbols: ["A","B","C","D","E"],
  rtp: 0.96, // demo target
  spin(){
    return Array.from({length:5},()=>this.symbols[Math.floor(Math.random()*5)]);
  }
};

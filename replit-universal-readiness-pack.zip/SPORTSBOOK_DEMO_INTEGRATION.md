Sportsbook demo UI-only, betting disabled.

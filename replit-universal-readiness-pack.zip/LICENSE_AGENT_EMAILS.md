Subject: Pre-License Demo – Technical Review

Demo-only platform, no real money. Evaluating Curaçao / Anjouan.

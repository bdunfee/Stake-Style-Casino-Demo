Subject: Demo-Only Platform – Pre-Onboarding

Payments disabled pending license.

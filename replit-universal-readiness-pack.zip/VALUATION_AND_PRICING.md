Valuation
Asset sale: $250k–$750k
SaaS: $10k–$30k/month

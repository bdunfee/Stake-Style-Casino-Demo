
import { useState } from 'react';
export default function DemoToolsDrawer({ children }: any) {
  const [open,setOpen]=useState(false);
  return (
    <div className="fixed bottom-4 right-4 z-50">
      <button className="px-3 py-2 text-sm bg-neutral-800 rounded-lg" onClick={()=>setOpen(!open)}>Demo Tools</button>
      {open && <div className="mt-2 w-72 bg-neutral-900 border border-neutral-700 rounded-xl p-4">{children}</div>}
    </div>
  );
}

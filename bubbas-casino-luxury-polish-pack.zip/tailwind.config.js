
module.exports = {
  theme: {
    extend: {
      transitionDuration: { luxury: '450ms', 'luxury-slow': '650ms' },
      spacing: { section: '3.5rem', 'section-lg': '5rem' },
      fontWeight: { ui: '500', 'ui-strong': '600', display: '700' }
    }
  }
}

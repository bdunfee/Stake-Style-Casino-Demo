
Extension pack for Replit Next.js Stake Demo
Adds slots, VIP, regulator dashboard, charts, admin guards, geo-blocking.


import Navbar from "../components/Navbar";
export default function VIP(){
  return (
    <>
      <Navbar/>
      <main style={{padding:24}}>
        <h1>VIP Program</h1>
        <ul>
          <li>Bronze – 5% rakeback</li>
          <li>Silver – 10% rakeback</li>
          <li>Gold – 20% rakeback</li>
        </ul>
      </main>
    </>
  );
}

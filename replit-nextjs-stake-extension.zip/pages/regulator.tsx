
import { withRole } from "../lib/guard";
function Regulator(){
  return (
    <div style={{padding:24}}>
      <h1>Regulator Dashboard</h1>
      <p>All balances simulated</p>
      <p>Fraud alerts: 0</p>
      <p>Jurisdiction blocks: Enabled</p>
    </div>
  );
}
export default withRole(Regulator, "admin");


import Navbar from "../components/Navbar";
export default function Slots(){
  const spin = () => alert("Demo spin 🎰");
  return (
    <>
      <Navbar/>
      <main style={{padding:24}}>
        <h1>Slots (Demo)</h1>
        <button onClick={spin}>SPIN</button>
      </main>
    </>
  );
}

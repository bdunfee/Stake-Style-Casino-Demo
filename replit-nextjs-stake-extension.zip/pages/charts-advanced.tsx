
import { LineChart, Line, XAxis, YAxis, Tooltip } from 'recharts';
const data = Array.from({length:20}).map((_,i)=>({t:i, users:Math.random()*200}));
export default function ChartsAdvanced(){
  return (
    <div style={{padding:24}}>
      <h1>Live Analytics</h1>
      <LineChart width={600} height={300} data={data}>
        <XAxis dataKey="t"/><YAxis/><Tooltip/>
        <Line type="monotone" dataKey="users" stroke="#3bc48b"/>
      </LineChart>
    </div>
  );
}

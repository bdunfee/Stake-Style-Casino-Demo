
import { useState } from 'react';
export default function GuidedTour(){
  const steps = [
    "Demo balances only",
    "Provably fair visualizer",
    "Geo-blocking controls",
    "Audit & compliance ready"
  ];
  const [i,setI]=useState(0);
  if(i>=steps.length) return null;
  return (
    <div style={{
      position:'fixed',bottom:20,right:20,
      background:'#1a1d24',padding:16,borderRadius:12
    }}>
      <p>{steps[i]}</p>
      <button onClick={()=>setI(i+1)}>Next</button>
    </div>
  );
}

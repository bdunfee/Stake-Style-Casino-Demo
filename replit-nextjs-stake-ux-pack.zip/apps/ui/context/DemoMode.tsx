
import { createContext, useContext, useState } from 'react';
const DemoCtx = createContext(null);
export function DemoProvider({children}){
  const [demo,setDemo]=useState(true);
  return (
    <DemoCtx.Provider value={{demo,setDemo}}>
      {children}
    </DemoCtx.Provider>
  );
}
export const useDemo = ()=>useContext(DemoCtx);

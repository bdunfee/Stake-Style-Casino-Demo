
import { useDemo } from '../context/DemoMode';
export default function DemoToggle(){
  const {demo,setDemo}=useDemo();
  return (
    <div style={{padding:24}}>
      <h1>Demo Mode</h1>
      <p>Status: {demo?'READ-ONLY':'INTERACTIVE'}</p>
      <button onClick={()=>setDemo(!demo)}>Toggle</button>
    </div>
  );
}

/data-room
  /01_Product
    - Platform_Overview.pdf
    - Screenshots/
  /02_Compliance
    - Age_Gating.md
    - Geo_Blocking.md
  /03_Legal
    - IP_Ownership.md
    - Demo_Only_Memo.md
  /04_Commercial
    - Pricing.md
    - Valuation.md
  /05_Roadmap
    - License_Fork.md
    - 90_Day_Launch.md

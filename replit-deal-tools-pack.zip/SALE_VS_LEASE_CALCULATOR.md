Sale vs Lease Logic

Sale:
- One-time: $500k–$1M

Lease:
- Setup: $25k
- Monthly: $20k
- 12 months ≈ $265k
- 36 months ≈ $745k

Lease overtakes sale after ~24–30 months.

Merge Sportsbook Demo into Lobby

1. Add a lobby tile labeled 'Sportsbook (Demo)'
2. Route to /sportsbook
3. Display disclaimer: Betting Disabled
4. No wallet hooks

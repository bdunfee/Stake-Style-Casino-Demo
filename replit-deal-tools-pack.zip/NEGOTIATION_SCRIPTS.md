Price Anchoring Scripts

If selling:
"Comparable pre-license platforms trade between $500k–$1M. Given our readiness, we are anchoring at the top of that range."

If leasing:
"Our standard SaaS terms are $25k setup, $20k/month, plus revenue share."

If buyer pushes down:
"Reducing price removes bundled compliance and sportsbook preview."

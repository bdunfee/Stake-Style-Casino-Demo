
const setup = 25000;
const monthly = 20000;
function leaseRevenue(months){
  return setup + monthly * months;
}
console.log(leaseRevenue(12), leaseRevenue(36));

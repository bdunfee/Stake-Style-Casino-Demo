
import React from 'react';

export default function SportsbookDemo() {
  return (
    <div style={{ padding: 32 }}>
      <h1>Sportsbook Preview</h1>
      <p>UI-only demo. Betting disabled.</p>
      <div className="match">Team A vs Team B — Odds 1.9 / 2.1</div>
    </div>
  );
}

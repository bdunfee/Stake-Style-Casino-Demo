
export function learn(stats, tier){
  if(tier==="HARD") stats.aggression+=0.01;
  if(tier==="EASY") stats.caution+=0.01;
  return stats;
}

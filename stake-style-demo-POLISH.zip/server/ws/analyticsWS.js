
import { WebSocketServer } from "ws";
export function startAnalyticsWS(server){
  const wss = new WebSocketServer({ server });
  setInterval(()=>{
    const payload = JSON.stringify({
      users: Math.floor(Math.random()*200),
      bets: Math.floor(Math.random()*800)
    });
    wss.clients.forEach(c=>c.send(payload));
  },1000);
}

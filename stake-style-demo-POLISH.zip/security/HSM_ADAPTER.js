
export class HSM {
  constructor(mode="MOCK"){ this.mode=mode }
  sign(tx){
    if(this.mode==="MOCK") return "mock-signature";
    // REAL mode connects to CloudHSM / Ledger / Fireblocks
  }
}


import { useEffect, useState } from "react";
export default function LiveChart(){
  const [d,setD]=useState([]);
  useEffect(()=>{
    const ws=new WebSocket("ws://localhost:3000");
    ws.onmessage=e=>setD(p=>[...p.slice(-20),JSON.parse(e.data)]);
  },[]);
  return <pre>{JSON.stringify(d,null,2)}</pre>;
}

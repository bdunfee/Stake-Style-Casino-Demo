
export default function LobbyGrid({items}){
  return (
    <div className="grid">
      {items.map(i=>(
        <div className="card" key={i.id}>
          <img src={i.img}/>
          <span>{i.name}</span>
        </div>
      ))}
      <style jsx>{`
        .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:16px}
        .card{transition:transform .12s ease,box-shadow .12s ease}
        .card:hover{transform:translateY(-6px);box-shadow:0 12px 40px rgba(0,0,0,.5)}
      `}</style>
    </div>
  )
}

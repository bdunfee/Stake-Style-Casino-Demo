import { WebSocketServer } from 'ws';

export function startWSS(server:any) {
  const wss = new WebSocketServer({ server });
  wss.on('connection', ws => {
    ws.send(JSON.stringify({ type: 'metrics', online: 1 }));
  });
}

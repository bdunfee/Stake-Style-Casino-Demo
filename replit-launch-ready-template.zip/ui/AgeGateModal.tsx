import { useEffect, useState } from 'react';

export default function AgeGateModal() {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    if (!localStorage.getItem('ageGateSeen')) setOpen(true);
  }, []);
  if (!open) return null;
  return (
    <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,.7)',display:'flex',alignItems:'center',justifyContent:'center',zIndex:9999}}>
      <div style={{background:'#111',color:'#fff',padding:24,borderRadius:12,maxWidth:420}}>
        <h2>18+ Only</h2>
        <p>Age verification required before withdrawals.</p>
        <button onClick={()=>{localStorage.setItem('ageGateSeen','1');setOpen(false);}}>I Understand</button>
      </div>
    </div>
  );
}

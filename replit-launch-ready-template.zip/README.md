# Launch‑Ready Crypto Casino (Replit Template)

This template combines **casino UI**, **real‑time engine stubs**, and **full compliance**.
Designed for instant boot on Replit.

## Run
- Node 18
- `npm install`
- `npm run dev`

## Environment (Replit Secrets)
MIN_AGE=18
BLOCKED_COUNTRIES=US,UK,FR,NL
SUMSUB_WEBHOOK_SECRET=change_me
WITHDRAWAL_APPROVALS_REQUIRED=2
FRAUD_SCORE_KYC_THRESHOLD=0.7

## What’s included
- Next.js app (UI scaffold)
- WebSocket server stub
- Deposit/withdraw flow stubs
- KYC webhook endpoint
- Age‑gate modal
- Compliance dashboards
- Reports & SOPs

## Demo vs Real Money
- DEMO_MODE=true (default)
- Flip to false post‑license

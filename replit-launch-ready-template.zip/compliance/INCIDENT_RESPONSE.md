# Incident Response & Regulator Contact

## Triggers
- Underage access
- Fraud spike
- Wallet compromise
- KYC provider outage

## Steps
1. Freeze affected accounts
2. Preserve logs
3. Notify Compliance Officer
4. Notify Regulator within required timeframe
5. Remediate and document

## Regulator Contact
- Curaçao GCB: compliance@gcb.cw

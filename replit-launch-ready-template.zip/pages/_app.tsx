import AgeGateModal from '../ui/AgeGateModal';
import '../styles/globals.css';

export default function App({ Component, pageProps }) {
  return (
    <>
      <AgeGateModal />
      <Component {...pageProps} />
    </>
  );
}

import type { NextApiRequest, NextApiResponse } from 'next';

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  // Verify provider signature here
  // Update user KYC + age flags
  res.status(200).json({ ok: true });
}

export function shouldEscalateToKYC(fraudScore: number) {
  const threshold = Number(process.env.FRAUD_SCORE_KYC_THRESHOLD || 0.7);
  return fraudScore >= threshold;
}

export type WithdrawalStatus =
  | 'requested'
  | 'pending_approval'
  | 'approved'
  | 'rejected'
  | 'paid';

export function requiresApproval(amount: number) {
  return amount >= 1000; // configurable
}

export function approvalsNeeded() {
  return Number(process.env.WITHDRAWAL_APPROVALS_REQUIRED || 2);
}

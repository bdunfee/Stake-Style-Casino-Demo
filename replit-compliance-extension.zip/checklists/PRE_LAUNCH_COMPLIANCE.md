# Pre-Launch Compliance Checklist

- [ ] Age verification enforced before withdrawals
- [ ] KYC provider webhooks active
- [ ] Jurisdiction blocking tested
- [ ] Responsible gambling limits enabled
- [ ] Withdrawal approvals configured
- [ ] Audit logging enabled
- [ ] Regulator demo accounts created
- [ ] License documents uploaded
- [ ] Monthly reporting scheduled

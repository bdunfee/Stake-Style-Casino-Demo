# Compliance Extension (Replit)

Adds:
- Withdrawal signing & dual-approval flow
- Live compliance metrics (WebSocket-ready)
- Automated monthly regulator PDF reports
- Fraud score driven KYC escalation
- Pre-launch compliance checklist

Install:
1. Upload ZIP to Replit and Extract
2. Set env vars in Secrets
3. Wire admin routes

# Live Compliance Metrics

Expose via WebSocket:
- Active users
- KYC pending / approved
- Underage blocks
- Jurisdiction blocks
- Withdrawals pending approval

Metrics are read-only for compliance officers.

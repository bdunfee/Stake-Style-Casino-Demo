// Cron-triggered monthly report generator (stub)
export function generateMonthlyReport(month: string) {
  return {
    month,
    kycApproved: 0,
    withdrawalsProcessed: 0,
    jurisdictionBlocks: 0,
    underageAttempts: 0
  };
}

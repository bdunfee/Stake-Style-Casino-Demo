import { useEffect, useState } from 'react';

export default function AgeGateModal() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const seen = localStorage.getItem('ageGateSeen');
    if (!seen) setOpen(true);
  }, []);

  if (!open) return null;

  return (
    <div style={overlay}>
      <div style={modal}>
        <h2>18+ Only</h2>
        <p>
          This platform is intended for users aged 18 and over.
          Age verification is required before real-money withdrawals.
        </p>
        <button onClick={() => {
          localStorage.setItem('ageGateSeen', 'true');
          setOpen(false);
        }}>I Understand</button>
      </div>
    </div>
  );
}

const overlay = {
  position: 'fixed',
  top: 0,
  left: 0,
  right: 0,
  bottom: 0,
  background: 'rgba(0,0,0,0.7)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  zIndex: 9999
};

const modal = {
  background: '#111',
  color: '#fff',
  padding: '24px',
  borderRadius: '12px',
  maxWidth: '420px',
  textAlign: 'center'
};

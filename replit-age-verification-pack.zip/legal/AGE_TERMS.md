## Age Restriction

Access to and use of the Platform is strictly limited to individuals who are **at least eighteen (18) years of age**, or such higher minimum age as required by law.

By creating an account, the user represents that they meet the minimum age requirement. The Operator reserves the right to verify age and identity at any time, including prior to withdrawals.

If a user is found to be underage, the account will be suspended and handled in accordance with applicable laws.

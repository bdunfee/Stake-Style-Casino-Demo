# Sumsub Settings

Create Verification Level: REAL_MONEY_WITHDRAWAL_KYC

Enable:
- Identity Document (Passport, ID, Driver's License)
- DOB Extraction
- Age Validation Rule: >= 18
- Document Authenticity
- Liveness (Passive)

Disable:
- Proof of Address
- Enhanced Due Diligence

Webhooks:
- applicantReviewed
- applicantPending
- applicantRejected

# Onfido Settings

Workflow: Withdrawal_KYC_Age_Check

Checks:
- Identity Document
- Facial Similarity
- DOB Extraction
- Age Rule >= 18

Disable:
- Address Verification
- AML (optional later)

# Regulator Screenshot Walkthrough

1. Signup (no KYC)
2. Deposit screen (no KYC)
3. Withdrawal request (KYC triggered)
4. KYC provider screen (DOB visible)
5. Admin dashboard (Age verified flag)
6. Underage rejection demo

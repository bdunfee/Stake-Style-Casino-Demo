# Age Verification & Compliance Pack (Replit)

This pack adds:
- Non-blocking 18+ age-gate modal (Next.js)
- Terms & Footer wording
- Sumsub / Onfido exact toggle settings
- Regulator walkthrough checklist

## How to use
1. Unzip into your Replit project root
2. Import the modal component and render it in _app.tsx
3. Copy legal wording into your Terms page & footer
4. Configure Sumsub/Onfido using the provided settings

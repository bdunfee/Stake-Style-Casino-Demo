Investor Outreach

Email opener:
"We’ve built a demo-only, pre-license casino platform designed for fast regulatory approval. Would you like a short walkthrough?"

Call structure:
1. What problem we solve (time-to-license)
2. What’s built today (demo)
3. Monetization paths
4. Next steps

import React from 'react';

export default function SportsbookTile(){
  return (
    <div style={{
      padding:20,
      borderRadius:16,
      background:'linear-gradient(135deg,#111,#1c1c1c)',
      transition:'transform .3s',
    }}>
      <h3>Sportsbook</h3>
      <p>Preview</p>
    </div>
  );
}
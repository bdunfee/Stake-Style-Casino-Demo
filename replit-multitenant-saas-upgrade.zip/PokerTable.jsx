
import { useState } from "react";

export default function PokerTable({ seatCount = 6 }) {
  const [players, setPlayers] = useState([
    { id: 1, name: "You", type: "human", chips: 1000 },
    { id: 2, name: "BubbaBot Easy", type: "bot", chips: 1000 },
    { id: 3, name: "BubbaBot Medium", type: "bot", chips: 1000 }
  ]);

  return (
    <div className="p-6 bg-neutral-900 rounded-2xl text-white">
      <h2 className="text-xl font-semibold mb-4">Poker Table</h2>
      <div className="grid grid-cols-3 gap-4">
        {players.map(p => (
          <div key={p.id} className="bg-neutral-800 p-4 rounded-xl">
            <div className="font-medium">{p.name}</div>
            <div className="text-xs opacity-70">{p.type}</div>
            <div className="mt-2">Chips: {p.chips}</div>
          </div>
        ))}
      </div>
      <button className="mt-6 bg-green-500 text-black px-4 py-2 rounded">Start Hand</button>
    </div>
  );
}

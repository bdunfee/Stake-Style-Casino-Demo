
import { sha256 } from "./pfCommon";

export async function verifyDice({ serverSeed, clientSeed, nonce }) {
  const hash = await sha256(`${serverSeed}:${clientSeed}:${nonce}`);
  const roll = (parseInt(hash.slice(0, 8), 16) % 10000) / 100;
  return roll;
}


import { sha256 } from "./pfCommon";

export async function verifySlots({ serverSeed, clientSeed, nonce, reels }) {
  const hash = await sha256(`${serverSeed}:${clientSeed}:${nonce}`);
  const numbers = hash.match(/.{1,8}/g).map(h => parseInt(h, 16));
  return numbers.slice(0, reels.length).map((n,i)=> n % reels[i].length);
}

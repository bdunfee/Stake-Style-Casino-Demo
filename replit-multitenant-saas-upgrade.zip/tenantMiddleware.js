
export function resolveTenant(req) {
  const host = req.headers.host || "";
  const subdomain = host.split(".")[0];
  return subdomain || "default";
}

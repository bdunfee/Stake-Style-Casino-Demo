
import { sha256 } from "./pfCommon";

export async function verifyPokerShuffle({ serverSeed, clientSeed, nonce, deck }) {
  let seed = await sha256(`${serverSeed}:${clientSeed}:${nonce}`);
  let cards = [...deck];
  for (let i = cards.length - 1; i > 0; i--) {
    seed = await sha256(seed);
    const j = parseInt(seed.slice(0, 8), 16) % (i + 1);
    [cards[i], cards[j]] = [cards[j], cards[i]];
  }
  return cards;
}

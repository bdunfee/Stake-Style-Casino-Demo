Day 1 After License
- Enable payments
- Activate live KYC
- Turn on withdrawals
- Notify PSPs
- Switch demo banners OFF
- Enable regulator reporting

Subject: Pre-License Platform Demo – License Application Inquiry

Hello [Agent Name],

We have completed a pre-license, demo-only casino platform prepared for technical review.
Key points:
- Demo-only (no real money)
- Geo-aware age gating
- Provably fair visualization
- Audit logs & compliance dashboards

We are seeking guidance on licensing under [Curaçao/Anjouan].

Best regards,
Bubba’s Casino Team

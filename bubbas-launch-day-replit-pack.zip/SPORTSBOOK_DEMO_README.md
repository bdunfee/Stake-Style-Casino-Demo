Sportsbook Demo (Non-Betting)
- UI only
- Fake odds
- Watchlists
- Betting disabled

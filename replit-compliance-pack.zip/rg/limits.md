# Responsible Gambling Limits

Supported:
- Daily deposit cap
- Weekly loss limit
- Self-exclusion (7/30/90 days)
- Cool-off period (24h)

Enforced server-side before accepting bets or deposits.

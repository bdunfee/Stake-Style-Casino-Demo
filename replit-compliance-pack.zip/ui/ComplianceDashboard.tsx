export default function ComplianceDashboard() {
  return (
    <div style={{padding:24}}>
      <h1>Compliance Officer Dashboard</h1>
      <ul>
        <li>Active Users</li>
        <li>KYC Approved / Pending</li>
        <li>Age Verified Count</li>
        <li>Blocked Jurisdictions Hits</li>
        <li>Audit Log Export (CSV)</li>
      </ul>
    </div>
  );
}

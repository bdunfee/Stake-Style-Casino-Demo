export const MIN_AGE = 18;

export const BLOCKED_COUNTRIES = new Set(
  (process.env.BLOCKED_COUNTRIES || '').split(',').filter(Boolean)
);

export function isCountryBlocked(cc: string) {
  return BLOCKED_COUNTRIES.has(cc.toUpperCase());
}

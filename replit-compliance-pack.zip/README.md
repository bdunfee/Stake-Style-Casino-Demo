# Compliance Pack (Replit)

Includes:
- Auto country blocking + age rules
- KYC webhook wiring (Next.js API)
- License submission PDF
- Responsible gambling limits
- Compliance officer dashboard (read-only)

## Install
1. Upload ZIP to Replit and Extract
2. Add env vars listed in `.env.example`
3. Deploy

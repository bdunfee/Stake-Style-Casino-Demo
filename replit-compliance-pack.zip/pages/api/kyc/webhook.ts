import type { NextApiRequest, NextApiResponse } from 'next';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // Verify signature (pseudo)
  // const sig = req.headers['x-signature'];
  // verify(sig, process.env.SUMSUB_WEBHOOK_SECRET)

  const event = req.body;

  // Persist audit log (stub)
  console.log('KYC EVENT', event?.type);

  // Example enforcement
  if (event?.reviewResult?.reviewAnswer === 'GREEN') {
    // mark user kyc_status=approved, age_verified=true
  }

  res.status(200).json({ ok: true });
}
